import { bookings } from "./data-provider.js";

export default class BookingController {
    static findAll(params) {
        // добавить проверку параметров
        // добавить обработку плохих случаев
        // начать применять параметры

        return {
            status: 200,
            data: [...bookings],
        };
    }

    static create(payload) {
        // создавать Timeslot через .fromJSON
        // добавлять в bookings в формате toObject/toMapping

        const enhancedBooking = payload;
        // добавлять айди и таймстэмп создания

        bookings.push(enhancedBooking);

        return {
            status: 201,
            data: enhancedBooking,
        };
    }
}
