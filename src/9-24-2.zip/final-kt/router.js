export default class Router {
    #routes;

    constructor() {
        this.#routes = new Map();
    }

    #notFound() {
        return {
            status: 404,
            error: { message: "Not found" },
        };
    }

    register(pattern, handler) {
        this.#routes.set(JSON.stringify(pattern), handler);
    }

    handle({ method, url, body, params }) {
        const jsonPattern = JSON.stringify({ method, url });
        if (this.#routes.has(jsonPattern)) {
            return this.#routes.get(jsonPattern)(
                body || params
            );
        }
        return this.#notFound();
    }
}
