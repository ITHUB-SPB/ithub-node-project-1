import { createServer } from "node:http";

import Router from "./router.js";
import BookingController from "./controller.js";

const router = new Router();

router.register(
    { method: "GET", url: "/bookings" },
    BookingController.findAll
);

router.register(
    { method: "POST", url: "/bookings" },
    BookingController.create
);

const server = createServer((request, response) => {
    const { method, url } = request;

    const params = {};
    let body = null;

    const result = router.handle({
        method,
        url,
        body,
        params,
    });

    response.writeHead(result.status);
    response.end(JSON.stringify(result));
});

server.listen(3000, () => {
    console.log(
        "Server listening on http://localhost:3000"
    );
});
