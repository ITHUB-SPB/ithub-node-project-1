export const bookings = [
    { id: 1, start: 1765363613, end: 1765364813 },
    { id: 2, start: 1765463613, end: 1765484813 },
];
