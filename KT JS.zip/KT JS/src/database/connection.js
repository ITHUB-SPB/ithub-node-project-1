import sqlite from 'node:sqlite';

const con = new sqlite.DatabaseSync('db.sqlite3');

export default con;
