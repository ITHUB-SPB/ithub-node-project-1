import ora from 'ora';
import {createTables, resetTables} from './ddl.js';
import seedTables from './seed.js';
import chalk from 'chalk';






const zagruzka = ora('загрузка').start();


export default function cli() {

    const command = process.argv[2];





    if (command === 'create') {
        try {

            createTables();
            zagruzka.succeed(chalk.green('Таблицы созданы или они уже тут есть'));


        } catch (error) {

            zagruzka.fail(chalk.red(`ошбка при создании таблиц: ${error.message}`));
        }

    } else if (command === 'reset') {

        try {

            resetTables();

            zagruzka.succeed(chalk.green('Инфа из таблиц удалена'));
        } catch (error) {

            zagruzka.fail(chalk.red(`Ошибка при сбросе таблиц ${error.message}`));

        }

    } else if (command === 'seed') {

        try {

            seedTables();

            zagruzka.succeed(chalk.green('Тут в таблице не правдка'));

        } catch (error) {

            zagruzka.fail(chalk.red(`ошибка при наполнении таблиц ${error.message}`));

        }

    } else {




        
        zagruzka.fail(chalk.red('Такого нету. Напишите help'));
    }

}




export function help() {

    zagruzka.succeed(`какие комадны тут есть:(${chalk.green('create')}/${chalk.red('reset')}/${chalk.yellow('seed')}), ${chalk.green('\ndb:create - создание таблиц,')} ${chalk.green('\ndb:reset - удаление таблиц,')} ${chalk.green('\ndb:seed - наполнения таблиц фейкавыми данными')}`);

}



const command = process.argv[2]; 


if(command === 'help'){

    setTimeout(() => {

        help();

    }, 2000);



}else{


    setTimeout(() => {




        cli();
    }, 2000);
}