import sqlite from 'node:sqlite';
export function createTables() {

    const con = new sqlite.DatabaseSync('db.sqlite3');

    con.exec(`create table if not exists users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username STRING UNIQUE,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    con.exec(`create table if not exists bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        start INTEGER NOT NULL,
        end INTEGER NOT NULL,
        userId INTEGER,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    )`);
}

export function resetTables() {
    const args = process.argv.slice(2);
    const tablesToSeed = args.length > 1 ? args : ['users', 'bookings'];

    const con = new sqlite.DatabaseSync('db.sqlite3');

    if (tablesToSeed.includes('users')) {
        con.exec(`delete from users`);
    } 
    if (tablesToSeed.includes('bookings')) {
        con.exec(`delete from bookings`);
    }    
    con.close();
}